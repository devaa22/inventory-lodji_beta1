<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= $title ?? 'Login' ?></title>

    <link rel="stylesheet" 
          href="https://cdn.jsdelivr.net/npm/foundation-sites@6.8.1/dist/css/foundation.min.css">
</head>
<body>

<?= $this->renderSection('content') ?>

</body>
</html>